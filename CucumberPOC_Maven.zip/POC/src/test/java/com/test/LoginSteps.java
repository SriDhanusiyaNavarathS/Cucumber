package com.test;

import java.util.concurrent.TimeUnit;

import org.junit.rules.Timeout;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;

public class LoginSteps {
	WebDriver driver=null;
	@Given("browser is open")
	public void browser_is_open() {
		
		String projectpath= System.getProperty("user.dir");
		
		System.setProperty("webdriver.chrome.driver", projectpath + "/src/test/resources/Driver/chromedriver.exe");
		 driver= new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
         driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		 
	}

	@And("user is on login page")
	public void user_is_on_login_page() {
		driver.navigate().to("https://opensource-demo.orangehrmlive.com/");
		}

	@When("^user enters (.*) and (.*)$")//(.*) it can be anything
	public void user_enters_username_and_password(String Username, String Password) throws InterruptedException {
		driver.findElement(By.id("txtUsername")).sendKeys(Username);
		driver.findElement(By.id(("txtPassword"))).sendKeys(Password);
		Thread.sleep(2000);
		}
    
	@And("user clicks on login button")
	public void user_clicks_on_login_button() {
    driver.findElement(By.id("btnLogin")).click();
	}
	
	@Then("navigate to next page")
	public void navigate_to_next_page() throws InterruptedException {
    driver.findElement(By.id("welcome")).isDisplayed();
    Thread.sleep(2000);
    driver.close();
    driver.quit();
	}


}
