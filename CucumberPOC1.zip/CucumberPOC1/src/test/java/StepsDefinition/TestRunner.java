package StepsDefinition;
import org.junit.runner.*;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/resources/Features/login.feature", glue= {"StepsDefinition"}, 
monochrome= true, tags="@smoke")
public class TestRunner {

}
